rosrun xacro xacro -o gobot.urdf gobot.urdf.xacro
gz sdf -p gobot.urdf > gobot.sdf