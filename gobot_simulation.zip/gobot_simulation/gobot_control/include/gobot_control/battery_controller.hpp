#ifndef BATTERY_CONTROLLER
#define BATTERY_CONTROLLER

#include "ros/ros.h"
#include "gazebo_msgs/ContactsState.h"
#include "sonar/GetBatteryInfo.h"
#include "sonar/BatteryInfo.h"
#include "gobot_control/SetBattery.h"


void newLeftBattery(const gazebo_msgs::ContactsState::ConstPtr& msg);
void newRightBattery(const gazebo_msgs::ContactsState::ConstPtr& msg);

bool getBatteryInfo(sonar::GetBatteryInfo::Request &req, sonar::GetBatteryInfo::Response &res);
bool setBattery(gobot_control::SetBattery::Request &req, gobot_control::SetBattery::Response &res);

#endif
