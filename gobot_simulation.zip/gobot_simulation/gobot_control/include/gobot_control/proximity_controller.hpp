#ifndef PROXIMITY_CONTROLLER
#define PROXIMITY_CONTROLLER

#include "ros/ros.h"
#include "sensor_msgs/Range.h"
#include "sonar/GetShortSignal.h"
#include "sonar/ShortSignalMsg.h"

void newLeftSignal(const sensor_msgs::Range::ConstPtr& msg);
void newRightSignal(const sensor_msgs::Range::ConstPtr& msg);

bool getShortSignal(sonar::GetShortSignal::Request &req, sonar::GetShortSignal::Response &res);

#endif
